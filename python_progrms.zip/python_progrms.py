def add(a,b):
    return(a+b);
def sub(a,b):
    return(a-b);
def mul(a,b):
    return(a*b);
def div(a,b):
    return(a/b);
a=int(input('enter a number '))
b=int(input('enter a numbber'))
print('addition is :',add(a,b))
print('subtraction is:',sub(a,b))
print('multiple is:',mul(a,b))
print('division is:',div(a,b))
